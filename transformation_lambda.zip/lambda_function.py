import base64
import io
import json
import logging
import polars as pl

from datetime import datetime

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


print('Loading function')


def lambda_handler(event, context):
    output = []

    rename_cols = {
        'timestamp': 'alert_timestamp'
        , 'source': 'alert_source'
        , 'version': 'webhook_version'
        , 'sharedSecret': 'shared_secret'
        , 'sentAt': 'alert_sent_at'
        , 'organizationId': 'organization_id'
        , 'organizationName': 'organization_name'
        , 'organizationUrl': 'organization_url'
        , 'networkId': 'network_id'
        , 'networkName': 'network_name'
        , 'networkUrl': 'network_url'
        , 'deviceSerial': 'device_serial'
        , 'deviceMac': 'device_mac'
        , 'deviceName': 'device_name'
        , 'deviceUrl': 'device_url'
        , 'deviceTags': 'device_tags'
        , 'deviceModel': 'device_model'
        , 'alertId': 'alert_id'
        , 'alertType': 'alert_type'
        , 'alertTypeId': 'alert_type_id'
        , 'alertLevel': 'alert_level'
        , 'occurredAt': 'alert_occurred_at'
        #, 'alertConfigId': 'alert_config_id'
        #, 'alertConfigName': 'alert_config_name'
        #, 'alertData': 'alert_data'
        #, 'conditionId': 'condition_id'
        #, 'ts': 'event_timestamp'
        #, 'type': 'sensor_type'
        #, 'nodeId': 'node_id'
        #, 'sensorValue': 'sensor_value'
        #, 'startedAlerting': 'started_alerting'
        , 'networkTags': 'network_tags'
    }

    for record in event['records']:
        print(record['recordId'])
        logger.info(f"RecordId is: {record['recordId']}")
        payload = base64.b64decode(record['data']).decode('utf-8')
        logger.info(f"Payload is: {payload}")
        payload_stream = json.loads(payload)
        #payload_stream = io.BytesIO(payload.encode('utf-8'))
        # Do custom processing on the payload here

        #print(payload)
        df = pl.read_ndjson(io.StringIO(payload))
        #df = pl.DataFrame(payload)
        #df = pl.read_ndjson(payload)
        logger.info(f"df is: {df}")
        print(df)
        df = df.unnest('payload').unnest('alertData').rename(rename_cols)  # .explode('triggerData').unnest('triggerData').unnest('trigger').unnest('trigger')
        df = df.explode('network_tags').explode('device_tags')
        #df = df.with_columns(pl.col(['alert_timestamp', 'alert_sent_at']).str.to_datetime("%Y-%m-%dT%H:%M:%S.%fZ"))
        logger.info(f"Final Dataframe is {df}") 
        payload = df.write_ndjson()
        logger.info(f"payload 2 is: {payload}")

        print(payload)

        # End custom processing

        output_record = {
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': base64.b64encode(payload.encode('utf-8')).decode('utf-8')
        }
        output.append(output_record)
        logger.info(f"Output record is {output}")

    print('Successfully processed {} records.'.format(len(event['records'])))

    return {'records': output}
